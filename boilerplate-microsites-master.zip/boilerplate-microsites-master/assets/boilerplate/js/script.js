(function () {
  /**
  * You can write ES6 here and it will get compile to vinalla javascript
  */

  const greeting = (message) => {
    console.log(message);
  };

  greeting('this is just a test');
}());
