const main = require('./main');

module.exports = {
  main
};
